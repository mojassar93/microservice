package com.appsdeveloperblog.photoapp.discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PhotoAppDiscoveryServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
